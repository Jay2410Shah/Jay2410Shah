﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
  public  class ClientHandler
    {
        public StreamWriter ServerWriter { get; set; }
        public StreamReader ServerReader { get; set; }
        public string AccountName { get; set; }
        NetworkStream stream;
        // Default host name - localhost means that the server is running on the same computer as this client
        public int HostPort { get; set; } // Default host port - note that the port number is the same one as in the server code
        public TcpClient TcpClient { get; set; }


        public ClientHandler()
        {
            HostPort = 55055;
            TcpClient = new TcpClient();
        }

        // Handle server session
        public string WriteToServer(string command)
        {
            try
            {
                ServerWriter.WriteLine(command);

                return ServerReader.ReadLine();
            }
            catch (Exception ex) 
            {
            
            }
            return null;
            

        }
        public void WriteOnlyToServer(string command)
        {
            ServerWriter.WriteLine(command);
        }
        public bool Connect(string HostName)
        {


            try
            {
                TcpClient.Connect(HostName, HostPort);
                stream = TcpClient.GetStream();
                ServerReader = new StreamReader(stream);
                ServerWriter = new StreamWriter(stream);
                ServerWriter.AutoFlush = true;
                return true;
            }
            catch (IOException) // Exception takes us out of the loop, so client will end
            {
                Console.WriteLine("***Network Error***");
                return false;
            }
            catch (OutOfMemoryException)
            {
                return false;
                // Catch buffer overflow exception
                // Connection will close upon leaving the using block
            }



        }
    }
}
