﻿using Client.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        public ClientHandler Client { get; set; }
        public Form1()
        {
            InitializeComponent();
            Client = new ClientHandler();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtAccountName.Text) || string.IsNullOrEmpty(txtHostName.Text))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
                Client.AccountName = txtAccountName.Text;
                var result = Client.Connect(txtHostName.Text);
                if (!result)
                {
                    BlHelpers.ShowMessage(BlHelpers.UnsuccessfullConnectionMessage);
                    return;
                }
             
                string serverResponse = Client.WriteToServer(BlHelpers.CONNECT+":"+ Client.AccountName);
                if(!serverResponse.Contains(BlHelpers.CONNECT+":"))
                {
                    BlHelpers.ShowMessage(BlHelpers.UnsuccessfullConnectionMessage);
                    return;
                }
                else
                {
                frmDashboard frmDashboard = new frmDashboard(Client);
                frmDashboard.Text = "ShopClient, "+serverResponse.Split(':')[1];
                this.Hide();
                frmDashboard.ShowDialog();
                this.Close();
                }

        }
    }
}