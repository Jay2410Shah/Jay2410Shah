﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client.Helpers
{
  public static  class BlHelpers
    {
        public const string CLIENT_ID= "CLIENT_ID", NOT_VALID= "NOT_VALID", DISCONNECT = "DISCONNECT", GET_PRODUCTS = "GET_PRODUCTS", GET_ORDERS = "GET_ORDERS", CONNECT = "CONNECT", PURCHASE = "PURCHASE";
        public const string UnsuccessfullConnectionMessage = "The client's connection attempt is unsuccessful. The account_no is not valid.";
        public static void ShowMessage(string message)
        {
            MessageBox.Show(message);
            return;
        }
    }
}
