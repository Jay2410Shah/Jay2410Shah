﻿using Client.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class frmDashboard : Form
    {
        public ClientHandler Client { get; set; }
        public frmDashboard(ClientHandler _client)
        {
            InitializeComponent();
            Client = _client;
            PopulateProducts(Client.WriteToServer(BlHelpers.GET_PRODUCTS));
           
          
        }
        public void PopulateProducts(string serverResponse)
        {
            
            var prodList = serverResponse.Replace("PRODUCTS:", "").Split('|');
            foreach (var prod in prodList)
            {
                var ProdName = prod.Split(',')[0];
                cmbProduct.Items.Add(ProdName);
            }
            cmbProduct.SelectedIndex = 0;
            
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnPurchase_Click(object sender, EventArgs e)
        {
            string selectedProduct = cmbProduct.Text;
            if(selectedProduct=="")
            {
                MessageBox.Show("Please select a product first");
                return;
            }
           var serverResponse= Client.WriteToServer(BlHelpers.PURCHASE+":"+ selectedProduct);
            if (!serverResponse.Contains("PURCHASE:"))
            {
                if (serverResponse.Contains(BlHelpers.NOT_VALID))
                {
                MessageBox.Show("The specified product is not valid.");
                }
                else
                MessageBox.Show("The product is not available (i.e., is already purchased by another client) and cannot be purchase.");

            }

            else
            {
                string orders = Client.WriteToServer(BlHelpers.GET_ORDERS);
                if (orders == "Orders:") return;
                PopulateOrder(orders);
            }


        }

        private void PopulateOrder(string orders)
        {
                listBox1.Items.Clear();
            var data = orders.Replace("Orders:", "");
                foreach (var item in data.Split('|'))
                {
                    listBox1.Items.Add(item);
                }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            Client.WriteOnlyToServer(BlHelpers.DISCONNECT);
            Application.Exit();
        }
    }
}
