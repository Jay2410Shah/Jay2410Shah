﻿using Server.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.BlHelpers
{
    public static class BlHelper
    {
       static Random random = new Random();

        public static List<Product> AllProducts = new List<Product>() {
            new Product() {Name= "Cricket Ticket",Quantity=random.Next(1,4) },
            new Product() {Name= "Football Ticket",Quantity=random.Next(1,4) },
            new Product() {Name= "Baseball Ticket",Quantity=random.Next(1,4) },
            new Product() {Name= "Hockey Ticket",Quantity=random.Next(1,4) },
            new Product() {Name= "Tennis Ticket",Quantity=random.Next(1,4)}

        };
        public static List<Product> AvailableProducts = AllProducts;
        public static List<UserAccount> Accounts = new List<UserAccount>() {
                new UserAccount() { AccountNumber = "1234",UserName="User1" },
                new UserAccount() { AccountNumber = "5678",UserName="User2" },
                new UserAccount() { AccountNumber = "9101",UserName="User3" },
                new UserAccount() { AccountNumber = "1123",UserName="User4" }
    };
        public static List<string> Orders { get; set; } = new List<string>();
        public static string ShowProducts()
        {
            string products = "PRODUCTS:";

            foreach (var item in AllProducts)
            {
                products += item.Name + "," + item.Quantity + "|";
            }
            return products.TrimEnd('|');
        }

      










        public static string CheckAccount(string AccountName)
        {
            var acc = Accounts.Where(x => x.AccountNumber == AccountName).FirstOrDefault();
            if (acc == null)
            {
                AccountName = "Invalid Account Number";
                return null;
            }

            AccountName = "User Logged successfully!";
            return acc.UserName;
        }

        public static UserAccount Authenticate(UserAccount account, out string Message)
        {

            if (Accounts.Where(x => x.AccountNumber == account.AccountNumber).FirstOrDefault() == null)
            {
                Message = "Invalid Account Number";
                return null;
            }

            Message = "User Logged successfully!";
            return account;
        }
    }
} 