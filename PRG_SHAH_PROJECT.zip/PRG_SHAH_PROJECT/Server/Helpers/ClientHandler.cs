﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server.BlHelpers
{

    public class ClientHandler
    {
        private readonly int clientNo;
        private readonly TcpClient  tcpClient;
        private readonly CancellationToken cancellationToken;
        const string NOT_AVAILABLE= "NOT_AVAILABLE", NOT_VALID= "NOT_VALID", CLIENT_ID= "CLIENT_ID", DISCONNECT = "DISCONNECT", GET_PRODUCTS = "GET_PRODUCTS", GET_ORDERS = "GET_ORDERS", CONNECT = "CONNECT", CONNECT_ERROR= "CONNECT_ERROR", PURCHASE = "PURCHASE";
        string ClientName { get; set; }  
        public ClientHandler(int _clientNo, TcpClient _tcpClient, CancellationToken _cancellationToken)
        {
            clientNo = _clientNo;
            tcpClient = _tcpClient;
            cancellationToken = _cancellationToken;
        }
        List<Product> products = BlHelper.AvailableProducts;
        public void Run()
        {
            // Using makes sure TcpClient is closed at end of scope
            using (tcpClient)
            {
                try
                {
                    NetworkStream stream = tcpClient.GetStream();
                    StreamReader reader = new StreamReader(stream);
                    StreamWriter writer = new StreamWriter(stream);
                    cancellationToken.Register(() =>
                    { // Close the stream when a cancellation is requested
                        Thread.Sleep(100); // Give 0.1s for clean protocol shutdown
                        stream.Close(); // May cause IOException
                    });
                    writer.AutoFlush = true; // Automatically flush output to the stream after each write
                                             //int number = -1;



                    while (true)
                    {
                        string line = reader.ReadLine();


                        if (line.Contains(GET_PRODUCTS))
                        {

                            Console.WriteLine(BlHelper.ShowProducts());
                            writer.WriteLine(BlHelper.ShowProducts());
                        }
                        else if (line.Contains(PURCHASE))
                        {


                            string orderName = line.Split(':')[1];
                            Product purchasingProduct = products.Where(x => x.Name == orderName).FirstOrDefault();
                            if (purchasingProduct == null)
                                writer.WriteLine(NOT_VALID);


                            else if (purchasingProduct.Quantity > 0)
                            {
                                purchasingProduct.Quantity -= 1;
                                string Order = purchasingProduct.Name + " - 1," + ClientName;
                                BlHelper.Orders.Add(Order);
                                writer.WriteLine(line);

                               

                            }
                            else
                            {
                                writer.WriteLine(NOT_AVAILABLE);
                                line = NOT_AVAILABLE;
                            }

                            Console.WriteLine(line);




                        }
                        else if (line.Contains(DISCONNECT))
                        {

                            Console.WriteLine(line);
                            break;

                        }
                        else if (line.Contains(CONNECT))
                        {
                            var userName = BlHelper.CheckAccount(line.Split(':')[1]);
                            if (userName!=null)
                            {
                                Console.WriteLine("CONNECT:" + userName);
                                writer.WriteLine("CONNECT:"+userName);
                                ClientName = userName;
                            }
                            else
                            {
                                Console.WriteLine(CONNECT_ERROR);
                                writer.WriteLine(CONNECT_ERROR);
                            }
                        }
                        else if (line.Contains(GET_ORDERS))
                        {
                            string Orders="Orders:";
                            foreach (var item in BlHelper.Orders)
                            {
                                Orders += item+"|";
                            }
                            Console.WriteLine(Orders);
                            writer.WriteLine(Orders);
                            Console.WriteLine(BlHelper.ShowProducts());


                        }

                    }
                }
                catch (IOException ex) // Exception takes us out of the loop, so client handler thread will end
                {
                    Console.WriteLine("***Network Error***");
                }
                catch (ObjectDisposedException)
                {
                    Console.WriteLine("***Network Error***"); // May occur if read  or write is attempted after stream is closed
                }
                catch (OutOfMemoryException)
                {
                    // Catch buffer overflow exception
                    // Connection will close upon leaving the using block
                }
            }
        }
    }
}